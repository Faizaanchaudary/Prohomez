import { Link, useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import styles from "./HomeProductDetail.module.css";
import FetchedImage from "../../components/FetchedImage";
import { AppDispatch, RootState } from "../../store/store";
import { fetchSingleProduct, fetchProductsByCategory } from "../../features/products/productSlice";
import { TiMinus, TiPlus } from "react-icons/ti";
import { IoMdArrowDropdown } from "react-icons/io";
import star from "../../assets/svg/star.svg";
import RatingComponent from "../../components/RatingComponent";
import HomeProductsVendorSidebar from "../../components/HomeProductsVendorSidebar";
import SuggestedProducts from "../../components/SuggestedProducts";
import Zoom from 'react-medium-image-zoom';
import 'react-medium-image-zoom/dist/styles.css';

interface Product {
  id: number;
  productName: string;
  slug: string;
  productPrice: number | string; 
  discountedPrice?: number | string; 
  featureImage: string;
  selectedCategory: string;
  reviews?: { rating: number; comment: string }[];
  vendorDetails?: {
    store_id: string;
    store_name: string;
    email?: string;
    store_phone?: string;
    image?: string;
  };
}

function HomeProductDetail() {
  const { slug } = useParams<{ slug: string }>();
  const dispatch = useDispatch<AppDispatch>();

  const product = useSelector((state: RootState) => state.products.singleProduct);
  const productStatus = useSelector((state: RootState) => state.products.status);
  const categoryProducts = useSelector((state: RootState) => state.products.categoryProducts) as Product[];

  const [value, setValue] = useState(1);
  const [isDescriptionExpanded, setIsDescriptionExpanded] = useState(false);
  const [currency, setCurrency] = useState("USD");
  const [suggestedProducts, setSuggestedProducts] = useState<any[]>([]);

  useEffect(() => {
    if (slug) {
      dispatch(fetchSingleProduct(slug));
    }
  }, [slug, dispatch]);

  useEffect(() => {
    if (product && product.selectedCategory) {
      dispatch(fetchProductsByCategory(product.selectedCategory));
    }
  }, [product, dispatch]);

  useEffect(() => {
    if (categoryProducts.length > 0) {
      const highestReviewedProduct = [...categoryProducts]
        .filter((p: Product) => (p.reviews?.length ?? 0) > 0)
        .sort((a, b) => (b.reviews?.length ?? 0) - (a.reviews?.length ?? 0))[0];
      setSuggestedProducts(highestReviewedProduct ? [highestReviewedProduct] : categoryProducts.slice(0, 8));
    }
  }, [categoryProducts]);

  const exchangeRates = { USD: 1, PKR: 280, AED: 3.67, GBP: 0.78 } as const;

  const formatCurrency = (amount: number, currency: string = 'USD') => {
    const formatter = new Intl.NumberFormat(undefined, {
      style: 'decimal',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
    
    return `${currency} ${formatter.format(amount)}`;
  };

 const convertPrice = (price: number | string, curr: string = currency) => {
  const numericPrice = typeof price === 'string' ? parseFloat(price) : price;
  const converted = numericPrice * (exchangeRates[curr as keyof typeof exchangeRates] || 1);
  return Number(converted.toFixed(2));
};
  const shouldTruncateDescription = (description: string | null, maxWords: number) => {
    if (!description) return false;
    const words = description.split(' ');
    return words.length > maxWords;
  };

  if (productStatus === "loading" || !product) return <div>Loading...</div>;

  const truncateDescription = (description: string | null, maxWords: number) => {
    if (!description) return '';
    const words = description.split(' ');
    return words.length > maxWords ? words.slice(0, maxWords).join(' ') + '...' : description;
  };

  const formatPlainText = (text: string | null): string => {
    if (!text) return '';

    return text
      .replace(/</g, "&lt;") 
      .replace(/>/g, "&gt;")
      .replace(/\n/g, "<br/>") 
      .replace(/•/g, '<span style="margin-right:5px;">•</span>'); 
  };

  return (
    <div className={styles.homeProductDetailMainBox1}>
      <section className={`${styles.homeProductDetailMainBox} py-5`}>
        <div className="container">
          <div className="row">
            <FetchedImage images={product.selectedImages || []} />
            <div className="col-md-6 px-4">
              <div className={`${styles.productDetailContentMainBox} py-3`}>
                <h2 className={styles.productName}>{product.productName}</h2>
                <h4 className={styles.vendorName}>
                  BY <Link
  to={`/pro/${
    (product?.vendorDetails?.store_name?.toLowerCase()  // Convert to lowercase
      .replace(/\s+/g, '-')                           // Replace spaces with hyphens
      .replace(/[^\w-]/g, '')                         // Remove special characters
      .replace(/-+/g, '-')                            // Replace multiple hyphens with single
      .replace(/^-+|-+$/g, '')                        // Trim hyphens from ends
    ) ?? 'no-store'                                   // Fallback if null/undefined
  }/${product?.vendorDetails?.store_id ?? ''}`}  >
                    {product.vendorDetails?.store_name || "Unknown Vendor"}
                  </Link>
                </h4>
                <div className={`${styles.reviewBox} d-flex py-1`}>
                  {product.numberOfReviews > 0 &&
                    Array.from({ length: product.numberOfReviews }).map((_, index) => (
                      <img key={index} src={star} alt="Pro Homez" className={styles.reviewStar} />
                    ))}
                </div>
                <RatingComponent productId={Number(product.id)} />
                
                <div className="currency-selector mt-2 mb-4" style={{ maxWidth: '300px' }}>
                  <div className="d-flex align-items-center gap-2 mb-2">
                    <label className={`${styles.labelclass}`}>Currency:</label>
                    <select 
                      value={currency} 
                      onChange={(e) => setCurrency(e.target.value)} 
                      className={`${styles.selectclass}`}
                      style={{ width: '120px' }}
                    >
                      <option value="USD">USD ($)</option>
                      <option value="PKR">PKR (₨)</option>
                      <option value="AED">AED (د.إ)</option>
                      <option value="GBP">GBP (£)</option>
                    </select>
                  </div>
                  
                  <div className={`${styles.priceContainer}`} style={{ maxWidth: '300px' }}>
  {product.discountedPrice && 
   Number(product.discountedPrice) < Number(product.productPrice) ? (
    <div className="d-flex flex-wrap align-items-center gap-2">
      <span className={`${styles.discountedPrice}`}>
        {formatCurrency(convertPrice(Number(product.discountedPrice)), currency)}
      </span>
      <span className={`${styles.originalPrice}`}>
        {formatCurrency(convertPrice(Number(product.productPrice)), currency)}
      </span>
      <span className={`${styles.discountBadge}`}>
        {Math.round(
          ((Number(product.productPrice) - Number(product.discountedPrice)) / 
          Number(product.productPrice)) * 100
        )}% OFF
      </span>
    </div>
  ) : (
    <span className={`${styles.regularPrice}`}>
      {formatCurrency(convertPrice(Number(product.productPrice)), currency)}
    </span>
  )}
</div>
                </div>
                
                <div className="d-flex flex-column flex-md-row gap-3 align-items-center my-3">
                  <div className={`${styles.cartValueBox} d-flex align-items-center`}>
                    <span className={styles.cartvalueController} onClick={() => setValue((prev) => Math.max(1, prev - 1))}>
                      <TiMinus />
                    </span>
                    <input
                      type="number"
                      className={styles.cartValueDisplay}
                      value={value}
                      onChange={(e) => setValue(Math.max(1, Math.min(15, parseInt(e.target.value, 10) || 1)))}
                    />
                    <span className={styles.cartvalueController} onClick={() => setValue((prev) => Math.min(15, prev + 1))}>
                      <TiPlus />
                    </span>
                  </div>
                  <button
                    className={`${styles.addToCartBtn} btn w-100 w-md-auto`}
                    onClick={() => {
                      const cart: any[] = JSON.parse(localStorage.getItem("cart") || "[]");
                      localStorage.setItem(
                        "cart",
                        JSON.stringify([
                          ...cart.filter((item) => item.id !== Number(product.id)),
                          { 
                            ...product, 
                            quantity: value,
                            selected_currency: currency, 
                            convertedPrice: convertPrice(product.discountedPrice || product.productPrice, currency)
                          }
                        ])
                      );
                      alert("Product added to cart successfully!");
                    }}
                  >
                    Add To Cart
                  </button>
                </div>
                
                <div className={`${styles.descriptionBox} pb-3`}>
                  <h5 className={styles.productDetailHeading}>Description</h5>
                  <div
                    dangerouslySetInnerHTML={{
                      __html: isDescriptionExpanded 
                        ? formatPlainText(product.productDescription)
                        : formatPlainText(truncateDescription(product.productDescription, 90)),
                    }}
                  />
                  {shouldTruncateDescription(product.productDescription, 90) && (
                    <button 
                      className={styles.seeMoreButton}
                      onClick={() => setIsDescriptionExpanded(!isDescriptionExpanded)}
                    >
                      {isDescriptionExpanded ? 'See Less' : 'See More'}
                    </button>
                  )}
                </div>
                
                <HomeProductsVendorSidebar vendorDetail={product.vendorDetails || {}} />
              </div>
            </div>
          </div>
        </div>
      </section>
      
      <div className={styles.suggestedDiv}>
        <h4 className={styles.suggestedHeading}>Suggested Products</h4>
        <div className={styles.suggestedContainer}>
          {suggestedProducts.map((suggestedProduct) => (
            <div key={suggestedProduct.id} className={styles.suggestedCard}>
              <Link to={`/products/home-products/${suggestedProduct.slug}`} className="text-decoration-none">
                <img 
                  src={`${import.meta.env.VITE_PROHOMEZ_BACKEND_URL}/images/${suggestedProduct.featureImage}`} 
                  alt={suggestedProduct.productName} 
                />
                <div className={styles.suggestedCardBody}>
                  <h3>{suggestedProduct.productName}</h3>
                  <p>Price: {formatCurrency(convertPrice(suggestedProduct.productPrice), currency)}</p>
                  <p>Category: {suggestedProduct.selectedCategory}</p>
                </div>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default HomeProductDetail;