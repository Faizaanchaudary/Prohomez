import VendorProfileMain from '../../components/VendorProfileMain'



const VendorProfilePage = () => {
 
  return (
    <>
    <VendorProfileMain />

    </>
  )
}

export default VendorProfilePage