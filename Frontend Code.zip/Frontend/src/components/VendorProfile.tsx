import React, { useEffect, useState } from "react";
import styles from "../style/VendorProfile.module.css";
import axios from "axios";
import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";
import { RootState } from "../store/store";

interface VendorProfileProps {
  store_id?: number;
  first_name?: string;
  last_name?: string;
  email?: string;
  store_phone?: string;
  image?: string;
  brand_type?: string;
  store_name?: string;
  address1?: string;
  address2?: string;
  city?: string;
  state_county?: string;
  country?: string;
  postcode?: string;
  isAdmin?: boolean;
  description?: string;
}

interface VendorProfileForm {
  first_name: string;
  last_name: string;
  email?: string;
  store_phone: string;
  password?: string;
  image?: FileList;
  description?: string;
  brand_type?: string;
  store_name?: string;
  address1?: string;
  address2?: string;
  city?: string;
  state_county?: string;
  country?: string;
  postcode?: string;
}

const VendorProfile: React.FC = () => {
  const [vendor, setVendor] = useState<VendorProfileProps | null>(null);
  const { register, handleSubmit, setValue } = useForm<VendorProfileForm>();
  const [updateStatus, setUpdateStatus] = useState<string>("");
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  const token = localStorage.getItem("token");

  const fetchVendorProfile = async () => {
    if (!token) {
      console.error("No authentication token found");
      return;
    }

    try {
      const res = await axios.get("/profile", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setVendor(res.data);

      // Prefill all form fields
      setValue("first_name", res.data.first_name);
      setValue("last_name", res.data.last_name);
      setValue("email", res.data.email);
      setValue("store_phone", res.data.store_phone);
      setValue("brand_type", res.data.brand_type || "");
      setValue("store_name", res.data.store_name || "");
      setValue("address1", res.data.address1 || "");
      setValue("address2", res.data.address2 || "");
      setValue("city", res.data.city || "");
      setValue("state_county", res.data.state_county || "");
      setValue("country", res.data.country || "");
      setValue("postcode", res.data.postcode || "");
      setValue("description", res.data.description || "");

      if (res.data.image) {
        setPreviewImage(
          `${import.meta.env.VITE_PROHOMEZ_BACKEND_URL}/images/${
            res.data.image
          }`
        );
      }
    } catch (err) {
      console.error("Error fetching vendor:", err);
    }
  };

  useEffect(() => {
    fetchVendorProfile();
  }, [setValue]);

  const onSubmit = async (data: VendorProfileForm) => {
    try {
      const formData = new FormData();
      formData.append("first_name", data.first_name);
      formData.append("last_name", data.last_name);
      formData.append("store_phone", data.store_phone);
      formData.append("email", data.email || "");
      formData.append("brand_type", data.brand_type || "");
      formData.append("store_name", data.store_name || "");
      formData.append("address1", data.address1 || "");
      formData.append("address2", data.address2 || "");
      formData.append("city", data.city || "");
      formData.append("state_county", data.state_county || "");
      formData.append("country", data.country || "");
      formData.append("postcode", data.postcode || "");
      
      if (data.password) {
        formData.append("password", data.password);
      }
      if (data.image && data.image.length > 0) {
        formData.append("image", data.image[0]);
      }
      if (data.description) {
        formData.append("description", data.description);
      }

      const response = await axios.put("/profile/update2", formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      });

      if (response.data) {
        setUpdateStatus("Profile updated successfully ✅");
        fetchVendorProfile();
      }
    } catch (error) {
      console.error("Update error:", error);
      setUpdateStatus("❌ Failed to update profile");
    }
  };

  return (
    <div
      className={`${styles.vendorprofile1} max-w-2xl mx-auto mt-10 bg-white shadow-lg rounded-lg p-6`}
    >
      <h2 className="text-2xl font-bold mb-4 text-center text-gray-700">
        Vendor Profile
      </h2>

      {previewImage && (
        <div className="flex justify-center mb-6">
          <img
            src={previewImage}
            alt="Profile"
            className={`${styles.vendorprofile2} w-32 h-32 rounded-full shadow-md`}
          />
        </div>
      )}

      {vendor ? (
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 p-4">
          <div className="flex flex-col justify-center align-center">
            <label className="font-semibold">Profile Image:</label>
            <input
              type="file"
              className="border p-2 rounded mt-1"
              {...register("image")}
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) {
                  setPreviewImage(URL.createObjectURL(e.target.files[0]));
                }
              }}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex flex-col">
              <label className="font-semibold">First Name:</label>
              <input
                type="text"
                {...register("first_name")}
                className="border p-2 rounded mt-1"
              />
            </div>

            <div className="flex flex-col">
              <label className="font-semibold">Last Name:</label>
              <input
                type="text"
                {...register("last_name")}
                className="border p-2 rounded mt-1"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex flex-col">
              <label className="font-semibold">Email:</label>
              <input
                type="email"
                {...register("email")}
                defaultValue={vendor.email}
                className="border p-2 rounded mt-1" 
              />
            </div>

            <div className="flex flex-col">
              <label className="font-semibold">Phone:</label>
              <input
                type="text"
                {...register("store_phone")}
                className="border p-2 rounded mt-1"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex flex-col">
              <label className="font-semibold">Brand Type:</label>
              <input
                type="text"
                {...register("brand_type")}
                className="border p-2 rounded mt-1"
              />
            </div>

            <div className="flex flex-col">
              <label className="font-semibold">Store Name:</label>
              <input
                type="text"
                {...register("store_name")}
                className="border p-2 rounded mt-1"
              />
            </div>
          </div>

          <div className="flex flex-col">
            <label className="font-semibold">Address Line 1:</label>
            <input
              type="text"
              {...register("address1")}
              className="border p-2 rounded mt-1"
            />
          </div>

          <div className="flex flex-col">
            <label className="font-semibold">Address Line 2:</label>
            <input
              type="text"
              {...register("address2")}
              className="border p-2 rounded mt-1"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex flex-col">
              <label className="font-semibold">City:</label>
              <input
                type="text"
                {...register("city")}
                className="border p-2 rounded mt-1"
              />
            </div>

            <div className="flex flex-col">
              <label className="font-semibold">State/County:</label>
              <input
                type="text"
                {...register("state_county")}
                className="border p-2 rounded mt-1"
              />
            </div>

            <div className="flex flex-col">
              <label className="font-semibold">Postcode:</label>
              <input
                type="text"
                {...register("postcode")}
                className="border p-2 rounded mt-1"
              />
            </div>
          </div>

          <div className="flex flex-col">
            <label className="font-semibold">Country:</label>
            <input
              type="text"
              {...register("country")}
              className="border p-2 rounded mt-1"
            />
          </div>

          <div className="flex flex-col">
            <label className="font-semibold">Description:</label>
            <textarea
              {...register("description")}
              className={`border p-2 rounded mt-1 placeholder-gray-500 ${styles["textarea-small"]}`}
              placeholder="Tell us about your store..."
            />
          </div>

          <div className="flex flex-col">
            <label className="font-semibold">Password:</label>
            <input
              type="password"
              {...register("password")}
              placeholder="Leave blank to keep current password"
              className="border p-2 rounded mt-1"
            />
          </div>

        

          <div className="flex justify-center mx-auto">
            <button
              type="submit"
              className={`${styles.vendorprofilesubmit} m-4 w-50 bg-green-500 text-white font-semibold py-2 rounded-full shadow-md hover:bg-green-600 transition duration-200`}
            >
              Update Profile
            </button>
          </div>

          {updateStatus && (
            <p
              className={`text-center mt-3 ${
                updateStatus.includes("Failed")
                  ? "text-red-500"
                  : "text-green-500"
              }`}
            >
              {updateStatus}
            </p>
          )}
        </form>
      ) : (
        <p className="text-center text-gray-500">Loading...</p>
      )}
    </div>
  );
};

export default VendorProfile;