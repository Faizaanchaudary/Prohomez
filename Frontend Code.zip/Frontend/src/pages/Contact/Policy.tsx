import React, { useEffect } from 'react';
import styles from './Policy.module.css';

const PrivacyPolicy: React.FC = () => {
  useEffect(() => {
    const animateOnScroll = () => {
      const sections = document.querySelectorAll(`.${styles.policySection}`);
      sections.forEach(section => {
        const sectionTop = section.getBoundingClientRect().top;
        const windowHeight = window.innerHeight;
        if (sectionTop < windowHeight * 0.75) {
          section.classList.add(styles.animate);
        }
      });
    };

    window.addEventListener('scroll', animateOnScroll);
    animateOnScroll();

    return () => window.removeEventListener('scroll', animateOnScroll);
  }, []);

  return (
    <div className={styles.privacyPolicyWrapper}>
      <div className={styles.policyHeaderContainer}>
        <div className={styles.headerMainContent}>
          <h1 className={styles.policyMainTitle}>Privacy Policy</h1>
          <p className={styles.policyEffectiveDate}>Last Updated: {new Date().toLocaleDateString()}</p>
        </div>
        <div className={styles.headerDecorativeElement}></div>
      </div>

      <div className={styles.policyContentArea}>
        {/* Section 1 */}
        <section className={`${styles.policySection} ${styles.policySection1}`}>
          <h2 className={styles.sectionMainTitle}>1. Who We Are</h2>
          <div className={styles.sectionTextContent}>
            <p>ProHomez.com is a global listing portal offering residential real estate (including homes, off-plan properties, ready-to-move properties, villas, mansions, and apartments) and home products (including furniture, tiles, sanitary items, art, paint, home decor, home appliances, and more).</p>
            <p>We provide a platform where vendors can showcase listings and maintain their own online stores. Our portal supports marketing, video content, listing services, and lead generation. Users can engage in global transactions in four currencies: USD, AED, PKR, and GBP.</p>
          </div>
        </section>

        {/* Section 2 */}
        <section className={`${styles.policySection} ${styles.policySection2}`}>
          <h2 className={styles.sectionMainTitle}>2. Information We Collect</h2>
          <div className={styles.sectionTextContent}>
            <p>We may collect the following types of information:</p>
            <ul className={styles.infoList}>
              <li><strong>Personal Information:</strong> Name, email address, phone number, postal address, and payment details.</li>
              <li><strong>Vendor Information:</strong> Store name, product listings, business address, and contact details.</li>
              <li><strong>Usage Information:</strong> IP address, browser type, pages viewed, referring/exit pages, and time spent on the site.</li>
              <li><strong>Cookies and Tracking Technologies:</strong> Used to personalize your experience and analyze site traffic.</li>
            </ul>
          </div>
        </section>

        {/* Section 3 */}
        <section className={`${styles.policySection} ${styles.policySection3}`}>
          <h2 className={styles.sectionMainTitle}>3. How We Use Your Information</h2>
          <div className={styles.sectionTextContent}>
            <p>We use your information to:</p>
            <ul className={styles.usageList}>
              <li>Provide and manage listings and vendor dashboards</li>
              <li>Facilitate transactions and communication between buyers and vendors</li>
              <li>Process payments in multiple currencies</li>
              <li>Deliver customer service and respond to inquiries</li>
              <li>Improve website functionality and user experience</li>
              <li>Conduct marketing and promotional activities</li>
            </ul>
          </div>
        </section>

        {/* Section 4 */}
        <section className={`${styles.policySection} ${styles.policySection4}`}>
          <h2 className={styles.sectionMainTitle}>4. Vendor Responsibilities</h2>
          <div className={styles.sectionTextContent}>
            <p>Vendors are responsible for:</p>
            <ul className={styles.responsibilityList}>
              <li>The accuracy of their product and property listings</li>
              <li>Timely delivery of home products to customers</li>
              <li>The quality, design, and condition of the listed products</li>
            </ul>
            <p>ProHomez.com provides a marketing and marketplace platform, but does not directly manufacture, stock, or ship products.</p>
          </div>
        </section>

        {/* Section 5 */}
        <section className={`${styles.policySection} ${styles.policySection5}`}>
          <h2 className={styles.sectionMainTitle}>5. Sharing Your Information</h2>
          <div className={styles.sectionTextContent}>
            <p>We do not sell your personal data. We may share information with:</p>
            <ul className={styles.sharingList}>
              <li>Payment processors and service providers to complete transactions</li>
              <li>Marketing platforms for promotional campaigns</li>
              <li>Law enforcement or regulatory bodies when legally required</li>
            </ul>
          </div>
        </section>

        {/* Section 6 */}
        <section className={`${styles.policySection} ${styles.policySection6}`}>
          <h2 className={styles.sectionMainTitle}>6. Data Security</h2>
          <div className={styles.sectionTextContent}>
            <p>We take reasonable precautions to protect your data from loss, misuse, unauthorized access, disclosure, or destruction. However, no online transmission or storage is completely secure.</p>
          </div>
        </section>

        {/* Section 7 */}
        <section className={`${styles.policySection} ${styles.policySection7}`}>
          <h2 className={styles.sectionMainTitle}>7. Your Rights</h2>
          <div className={styles.sectionTextContent}>
            <p>Depending on your location, you may have rights to:</p>
            <ul className={styles.rightsList}>
              <li>Access or correct your personal data</li>
              <li>Request deletion of your data</li>
              <li>Opt out of marketing communications</li>
              <li>Withdraw consent at any time</li>
            </ul>
          </div>
        </section>

        {/* Section 8 */}
        <section className={`${styles.policySection} ${styles.policySection8}`}>
          <h2 className={styles.sectionMainTitle}>8. Third-Party Links</h2>
          <div className={styles.sectionTextContent}>
            <p>Our platform may contain links to third-party websites. We are not responsible for their privacy practices or content.</p>
          </div>
        </section>

        {/* Section 9 */}
        <section className={`${styles.policySection} ${styles.policySection9}`}>
          <h2 className={styles.sectionMainTitle}>9. Children's Privacy</h2>
          <div className={styles.sectionTextContent}>
            <p>ProHomez.com is not intended for children under the age of 13. We do not knowingly collect personal data from children.</p>
          </div>
        </section>

        {/* Section 10 */}
        <section className={`${styles.policySection} ${styles.policySection10}`}>
          <h2 className={styles.sectionMainTitle}>10. Changes to This Policy</h2>
          <div className={styles.sectionTextContent}>
            <p>We may update this Privacy Policy from time to time. When we do, we will revise the "Effective Date" at the top of this page.</p>
            <p>ProHome.com will take all the right for the changes of their policies according to circumstances, without prior notice.</p>
          </div>
        </section>

        {/* Section 11 */}
        <section className={`${styles.policySection} ${styles.policySection11}`}>
          <h2 className={styles.sectionMainTitle}>11. Contact Us</h2>
          <div className={styles.sectionTextContent}>
            <p>If you have any questions about this Privacy Policy or your personal data, please contact us at:</p>
            <p className={styles.contactEmail}>Email: <a href="mailto:support@prohomez.com">support@prohomez.com</a></p>
          </div>
        </section>
      </div>

      <div className={styles.policyFooter}>
        <p>© {new Date().getFullYear()} ProHomez.com. All rights reserved.</p>
      </div>
    </div>
  );
};

export default PrivacyPolicy;