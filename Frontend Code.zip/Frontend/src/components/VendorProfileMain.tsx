import { useEffect, useState } from "react";
import { fetchVendorDetails2, fetchVendorProductsByStoreId, clearVendorProducts } from "../features/products/productSlice";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch, RootState } from "../store/store";
import { useParams } from "react-router-dom";
import ProductBox from "./ProductBox";
import defaultImage from '../assets/images/WhatsApp Image 2025-03-13 at 23.10.23_ac2acca4.jpg';
import styles from "../style/VendorProfileMain.module.css";

const VendorProfileMain = () => {
  const { vendorItems, status, error } = useSelector((state: RootState) => state.products);
  const vendor = useSelector((state: RootState) => state.products.vendorDetails);
  const dispatch = useDispatch<AppDispatch>();
  const { store_name, id } = useParams<{ store_name: string; id: string }>();
  const vendorId = id;
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (vendorId) {
      setLoading(true);
      // Clear previous vendor data before fetching new
      dispatch(clearVendorProducts());
      
      const fetchData = async () => {
        try {
          await dispatch(fetchVendorDetails2({ store_id: vendorId as string })).unwrap();
          await dispatch(fetchVendorProductsByStoreId({ store_id: vendorId  })).unwrap();
        } catch (err) {
          console.error("Failed to fetch vendor data:", err);
        } finally {
          setLoading(false);
        }
      };

      fetchData();
    }
  }, [vendorId, dispatch]);

  return (
    <div className={styles.container}>
      {/* Vendor Profile Section */}
      <div className={styles.profileSection}>
        {(vendor as any)?.image && (
          <img
            src={`${import.meta.env.VITE_PROHOMEZ_BACKEND_URL}/images/${(vendor as any)?.image}`}
            alt="Vendor Profile"
            className={styles.profileImage}
            onError={(e) => (e.currentTarget.src = defaultImage)}
          />
        )}

        <h1 className={styles.vendorName}>{(vendor as any)?.store_name}</h1>
        <p className={styles.vendorInfo}>{(vendor as any)?.address1 || "Address not available"}</p>
        <p className={styles.vendorInfo}>
          📧 {(vendor as any)?.email || "Email not available"} | 📞 {(vendor as any)?.store_phone || "Phone not available"}
        </p>
      </div>

      {/* About Section */}
      <div className={styles.aboutSection}>
        <h2 className={styles.aboutTitle}>About {(vendor as any)?.store_name}</h2>
        <p className={styles.description}>{(vendor as any)?.description || "No description available."}</p>
      </div>

      {/* Products Section */}
      <h2 className={styles.productsTitle}>Products</h2>
      <div className={styles.productsGrid}>
        {loading || status === "loading" ? (
          <p className={styles.vendorInfo}>Loading products...</p>
        ) : error ? (
          <p className={styles.vendorInfo}>No products available for this vendor.</p>
        ) : vendorItems.length === 0 ? (
          <p className={styles.vendorInfo}>This vendor hasn't added any products yet.</p>
        ) : (
          vendorItems.map((product, index) => (
            <div className={styles.productItem} key={index}>
              <ProductBox productDetail={product} />
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default VendorProfileMain;