import { Link } from 'react-router-dom';
import styles from '../style/ProductBox.module.css';
import { Product } from './types';
import star from '../assets/svg/star.svg'
import { useState } from 'react';

interface ProductBoxProps {
  productDetail: Product; 
}

function ProductBox({ productDetail }: ProductBoxProps) {
  const [imgError, setImgError] = useState(false);
  const { productName = 'Unnamed Product', featureImage = '/placeholder.png', productPrice, discountedPrice } = productDetail;
  
  const formatPrice = (price: number) => {
    return price?.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") || '0';
  };

  const generateSlug = (category?: string, productSlug?: string) => {
    const slugCategory = category?.toLowerCase().replace(/\s+/g, '-');
    return `/products/${slugCategory}/${productSlug}`;
  };

  const shouldShowDiscounted = discountedPrice && discountedPrice < productPrice;

  return (
    <Link to={generateSlug(productDetail.mainCategory, productDetail.slug)} className='text-decoration-none'>
      <div className={styles.productBox}>
        <img 
          src={`${import.meta.env.VITE_PROHOMEZ_BACKEND_URL}/images/${featureImage}`} 
          alt={productName} 
          className={`${styles.prouctImage}`} 
          onError={() => setImgError(true)}
        />
        <h3 className={`${styles.productName} mb-0`}>{productName}</h3>
        <div className={`${styles.reviewBox} d-flex py-1`}>
          {productDetail.numberOfReviews ? Array.from({ length: productDetail.numberOfReviews }).map((_, index) => (
            <img
              key={index}
              src={star}
              alt="Pro Homez"
              className={`${styles.reviewStar}`}
            />
          )) : null}
        </div>
        {productPrice && (
          <div className={styles.priceContainer}>
            {shouldShowDiscounted ? (
              <>
                <span className={styles.cuttedPrice}>
                  ${formatPrice(productPrice)}
                </span>
                <p className={styles.discountedPrice}>
                  ${formatPrice(discountedPrice)}
                </p>
              </>
            ) : (
              <span className={styles.originalPrice}>
                ${formatPrice(productPrice)}
              </span>
            )}
          </div>
        )}
      </div>
    </Link>
  );
}

export default ProductBox;