import styles from '../style/RealEstateListingAgentSidebar.module.css';
import vendorLogo from '../assets/images/WhatsApp Image 2025-03-13 at 23.10.23_ac2acca4.jpg';
import { VendorDetail } from './types';
import { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const API_BASE = import.meta.env.VITE_PROHOMEZ_BACKEND_URL;

interface RealEstateListingProps {
    vendorDetail: VendorDetail;
    storeId?: string;
}

function RealEstateListingAgentSidebar({ vendorDetail, storeId }: RealEstateListingProps) {
    const [vendorData, setVendorData] = useState<VendorDetail | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [previewImage, setPreviewImage] = useState<string | null>(null);

    useEffect(() => {
        let isMounted = true;
        
        const fetchVendorData = async () => {
            try {
                if (!storeId) {
                    setLoading(false);
                    return;
                }
                
                const response = await axios.get(`${API_BASE}/vendor-details/${storeId}`, {
                    headers: {
                        'Cache-Control': 'no-cache',
                        'Pragma': 'no-cache',
                        'Expires': '0'
                    }
                });
                
                if (isMounted) {
                    setVendorData(response.data);
                    
                    if (response.data.image) {
                        setPreviewImage(`${import.meta.env.VITE_PROHOMEZ_BACKEND_URL}/images/${response.data.image}`);
                    } else {
                        setPreviewImage(vendorLogo);
                    }
                }
            } catch (err) {
                if (isMounted) {
                    setError('Failed to fetch vendor details.');
                }
            } finally {
                if (isMounted) {
                    setLoading(false);
                }
            }
        };

        fetchVendorData();
        
        return () => {
            isMounted = false;
        };
    }, [storeId]);

    if (loading) return <div className={styles.loadingContainer}>Loading agent details...</div>;
    if (error) return <div className={styles.errorContainer}>{error}</div>;
    if (!vendorData) return <div className={styles.errorContainer}>Agent data not available.</div>;

    return (
        <div className={`${styles.realEstateListingAgent}`}>
            <h5 className={`${styles.listingAgentHeading}`}>Listing Agent</h5>
            <div className={`${styles.listingAgentDetailBox} d-flex my-4`}>
                <div className={`${styles.imgBox}`}>
                    <Link
  to={`/pro/${
    (vendorData.store_name || 'no-store')
      .toLowerCase()
      .replace(/\s+/g, '-')       // Replace spaces with hyphens
      .replace(/[^\w-]/g, '')     // Remove special characters
  }/${storeId || ''}`}>
                        <img
                            src={previewImage || vendorLogo}
                            alt="ProHomez"
                            className={styles.VendorProfileImage}
                        />
                    </Link>
                </div>
                <div className={`${styles.listingAgentDetail}`}>
                    <Link
  to={`/pro/${
    (vendorData.store_name || 'no-store')
      .toLowerCase()
      .replace(/\s+/g, '-')       // Replace spaces with hyphens
      .replace(/[^\w-]/g, '')     // Remove special characters
  }/${storeId || ''}`}
                        className="no-underline text-black"
                    >
                        <h4 className={`${styles.vendorName}`}>
                            {vendorData.store_name || 'No Store Name'}
                        </h4>
                        <p className={`${styles.vendorDetail} mb-0`}>
                            {vendorData.email || 'No email provided'}
                        </p>
                        <p className={`${styles.vendorDetail} mb-0`}>
                            {vendorData.store_phone || 'No phone provided'}
                        </p>
                    </Link>
                </div>
            </div>
             
                <div className={`${styles.contactButtons} pt-3`}>
                    <a href={`tel:+923155625755`} className={`${styles.vendorContactBtn} text-decoration-none btn`}>Speak with Agent</a>
                    <a href={`mailto:${vendorDetail.email}`} className={`${styles.vendorContactBtn} text-decoration-none btn`}>Reach Out via Email</a>
                </div>
        </div>
    );
}

export default RealEstateListingAgentSidebar;