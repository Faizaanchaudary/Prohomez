import { useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination, Thumbs } from "swiper/modules";
import SwiperCore from "swiper";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/thumbs";
import Zoom from 'react-medium-image-zoom';
import 'react-medium-image-zoom/dist/styles.css';
import styles from "../style/FetchedImage.module.css";

interface FetchedImageProps {
  images: string | string[];
}

const FetchedImage: React.FC<FetchedImageProps> = ({ images }) => {
  let imageArray: string[] = [];

  if (Array.isArray(images)) {
    imageArray = images;
  } else {
    try {
      imageArray = JSON.parse(images);
    } catch (error) {
      console.error("Error parsing images:", error);
      imageArray = [];
    }
  }

  const [thumbsSwiper, setThumbsSwiper] = useState<SwiperCore | null>(null);
  const [zoomEnabled, setZoomEnabled] = useState(true); // Enabled by default now

  // Toggle zoom functionality
  const toggleZoom = () => {
    setZoomEnabled(!zoomEnabled);
  };

  return (
    <div className={styles.fetchedImageContainer}>
      {/* Main Image Slider (With Navigation & Pagination) */}
      <Swiper
        modules={[Navigation, Pagination, Thumbs]}
        navigation
        pagination={{ clickable: true }}
        thumbs={{ swiper: thumbsSwiper }}
        className={styles.mainImageSlider}
      >
        {imageArray.map((img, index) => (
          <SwiperSlide key={index}>
            <div className={styles.imageContainer}>
              {zoomEnabled ? (
                <Zoom
                  zoomImg={{
                    src: `${import.meta.env.VITE_PROHOMEZ_BACKEND_URL}/images/${img}`,
                    alt: `Product Image ${index + 1}`,
                  }}
                  zoomMargin={40}
                >
                  <img
                    src={`${import.meta.env.VITE_PROHOMEZ_BACKEND_URL}/images/${img}`}
                    alt={`Product Image ${index + 1}`}
                    className={styles.mainImage}
                    style={{ cursor: 'zoom-in' }}
                  />
                </Zoom>
              ) : (
                <img
                  src={`${import.meta.env.VITE_PROHOMEZ_BACKEND_URL}/images/${img}`}
                  alt={`Product Image ${index + 1}`}
                  className={styles.mainImage}
                  style={{ cursor: 'zoom-out' }}
                  onClick={toggleZoom}
                />
              )}
              {/* Add zoom instruction hint */}
              <div className={styles.zoomHint}>
                {zoomEnabled ? "Click to zoom | Tap on mobile" : "Click to enable zoom"}
              </div>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>

      {/* Thumbnail Slider (No Navigation) */}
      {imageArray.length > 1 && (
        <Swiper
          modules={[Thumbs]}
          onSwiper={setThumbsSwiper}
          slidesPerView={Math.min(4, imageArray.length)}
          spaceBetween={imageArray.length > 5 ? 5 : 10}
          watchSlidesProgress
          className={styles.thumbnailSlider}
        >
          {imageArray.map((img, index) => (
            <SwiperSlide key={index}>
              <img
                src={`${import.meta.env.VITE_PROHOMEZ_BACKEND_URL}/images/${img}`}
                alt={`Thumbnail ${index + 1}`}
                className={styles.thumbnailImage}
              />
            </SwiperSlide>
          ))}
        </Swiper>
      )}
    </div>
  );
};

export default FetchedImage;