import cors from 'cors';

app.use(cors()); 