import { configureStore } from '@reduxjs/toolkit';
import productReducer from '../features/products/productSlice';
import postsReducer from '../features/posts/postsSlice';

const store = configureStore({
  reducer: {
    products: productReducer,
    posts: postsReducer,
  },
  middleware: (getDefaultMiddleware) => 
    getDefaultMiddleware({
      serializableCheck: {
        // Ignore these action types
        ignoredActions: ['products/clearVendorProducts'],
        // Ignore these paths in the state
        ignoredPaths: ['products.clearVendorProducts']
      }
    })
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export default store;