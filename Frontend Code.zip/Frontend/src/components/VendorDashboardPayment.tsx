import styles from "../style/VendorDashboardPayment.module.css"
function VendorDashboardPayment() {
  return (
    <div className={styles.dashboardpayment1}>
      <h1 className="">VendorDashboardPayment</h1>
    </div>
  );
}

export default VendorDashboardPayment;
