import { useEffect, useState } from "react";
import axios from "axios";
import styles from "./Orders.module.css";

const currencySymbols: Record<string, string> = {
  USD: '$',
  PKR: '₨',
  AED: 'د.إ',
  GBP: '£'
};

const formatNumberWithCommas = (num: number | string) => {
  const parsed = typeof num === 'number' ? num : parseFloat(num);
  if (isNaN(parsed)) return '0.00';
  return parsed.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
};

interface Order {
  order_id: string;
  client_details: {
    name: string;
    email: string;
    phone: string;
    address: string;
    city: string;
    state: string;
    country: string;
    postalCode: string;
    currency?: string;
  };
  cart_items: Array<{
    productName: string;
    quantity: number;
    productPrice: number;
    discountedPrice?: number;
    convertedPrice?: number; 
    selected_currency?: string;
  }>;
  total_cost: number;
  order_date: string;
  vendor_details: {
    store_id: string;
    store_name: string;
    VendorEmail: string;
    brand_type: string;
  }[];
  selected_currency: string;
}

interface VendorSidebarMainProps {
  isAdmin: boolean;
}

function Orders({ isAdmin }: VendorSidebarMainProps) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [deletingOrderId, setDeletingOrderId] = useState<string | null>(null);

  useEffect(() => {
    fetchOrders();
  }, [isAdmin]);

  const fetchOrders = async () => {
    const token = localStorage.getItem("token");

    if (!token) {
      setError("Unauthorized. Please log in.");
      setLoading(false);
      return;
    }

    try {
      const response = await axios.get(
        `${import.meta.env.VITE_PROHOMEZ_BACKEND_URL}/orders`,
        {
          headers: { Authorization: `Bearer ${token}` },
          params: { isAdmin: isAdmin ? 1 : 0 },
        }
      );

      if (!Array.isArray(response.data)) {
        throw new Error("Invalid API response");
      }

      setOrders(response.data);
    } catch (error) {
      if (axios.isAxiosError(error)) {
        setError(error.response?.data.message || "Failed to fetch orders");
      } else {
        setError("An unknown error occurred.");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteOrder = async (orderId: string) => {
    if (!window.confirm("Are you sure you want to delete this order?")) {
      return;
    }

    const token = localStorage.getItem("token");
    if (!token) {
      setError("Unauthorized. Please log in.");
      return;
    }

    setDeletingOrderId(orderId);

    try {
      await axios.delete(
        `${import.meta.env.VITE_PROHOMEZ_BACKEND_URL}/orders/${orderId}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      // Optimistically remove the order from UI
      setOrders(prevOrders => prevOrders.filter(order => order.order_id !== orderId));
    } catch (error) {
      if (axios.isAxiosError(error)) {
        setError(error.response?.data.message || "Failed to delete order");
      } else {
        setError("An unknown error occurred while deleting the order.");
      }
    } finally {
      setDeletingOrderId(null);
    }
  };

  // Extract unique categories
  const categories = Array.from(
    new Set(orders.map((order) => order.vendor_details?.[0]?.brand_type).filter(Boolean))
  );

  // Filtered orders based on category, search query (order_id or store_name)
  const filteredOrders = orders.filter((order) => {
    const matchesCategory = selectedCategory
      ? order.vendor_details?.[0]?.brand_type === selectedCategory
      : true;

    const matchesSearch =
      order.order_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.vendor_details.some((vendor) =>
        vendor.store_name.toLowerCase().includes(searchQuery.toLowerCase())
      );

    return matchesCategory && matchesSearch;
  });

  const getCurrencySet = (cartItems: Order['cart_items']) => {
    const set = new Set<string>();
    cartItems.forEach(item => {
      if (item.selected_currency) {
        set.add(item.selected_currency);
      }
    });
    return set;
  };

  if (loading) return <div>Loading orders...</div>;
  if (error) return <div className={styles.error}>{error}</div>;

  return (
    <div className="min-h-[100vh] px-4 py-6">
      <h2 className={`mb-4 ${styles.ordersHeading}`}>Your Orders</h2>

      {/* Search Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-4 mb-6 m-2">
        <input
          type="text"
          placeholder="Search by Order ID or Store Name..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="border border-gray-300 rounded-md px-4 py-2 w-full sm:w-1/2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Category Buttons */}
      <div className="flex flex-wrap gap-3 mb-6 m-2">
        <button
          className={`${styles.categoryButton} ${
            selectedCategory === null ? styles.categoryActive : ""
          }`}
          onClick={() => setSelectedCategory(null)}
        >
          All Categories
        </button>

        {categories.map((cat) => (
          <button
            key={cat}
            className={`${styles.categoryButton} ${
              selectedCategory === cat ? styles.categoryActive : ""
            }`}
            onClick={() => setSelectedCategory(cat)}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className={styles.ordersList}>
        {filteredOrders.length === 0 ? (
          <p className="text-center text-gray-500">No orders found.</p>
        ) : (
          filteredOrders.map((order) => (
            <div key={order.order_id} className={styles.orderCard}>
              <div className="flex justify-between items-start">
                <div>
                  <h4 className={styles.orderId}>Order ID: {order.order_id}</h4>
                  <p className={styles.orderDate}>
                    Date: {new Date(order.order_date).toLocaleDateString()}
                  </p>
                </div>
                {isAdmin === true && (  // Only show delete button if isAdmin is true
                  <button
                    onClick={() => handleDeleteOrder(order.order_id)}
                    disabled={deletingOrderId === order.order_id}
                    className={`${styles.deleteButton} ${
                      deletingOrderId === order.order_id ? styles.deleting : ""
                    }`}
                  >
                    {deletingOrderId === order.order_id ? "Deleting..." : "Delete"}
                  </button>
                )}
              </div>

             <p className={styles.vendorsContainer}>
  <strong className={styles.vendorsLabel}>Vendors:</strong>
  {order.vendor_details.map((vendor, index) => (
    <span key={index} className={styles.vendorName}>
      {vendor.store_name}
      {index < order.vendor_details.length - 1 && (
        <span className={styles.vendorSeparator}>, </span>
      )}
    </span>
  ))}
</p>

              <h5 className={styles.orderDetailHeading}>Customer Details:</h5>
              <p className={styles.orderdetailPara}>
                <strong className={styles.orderdetailstrong}>Name:</strong> {order.client_details.name}
                <br />
                <strong className={styles.orderdetailstrong}>Email:</strong> {order.client_details.email}
                <br />
                <strong className={styles.orderdetailstrong}>Number:</strong> {order.client_details.phone}
                <br />
                <strong className={styles.orderdetailstrong}>Address:</strong> {order.client_details.address}, {order.client_details.city}, {order.client_details.state}, {order.client_details.country} - {order.client_details.postalCode}
              </p>

              <h5 className={styles.orderDetailHeading}>Order Items:</h5>
              <ul>
                {order.cart_items.map((item, index) => {
                  const price = item.convertedPrice || (item.discountedPrice || item.productPrice);
                  const totalPrice = price * item.quantity;
                  const itemCurrency = item.selected_currency || order.selected_currency || 'USD';
                  const symbol = currencySymbols[itemCurrency] || itemCurrency;
                  
                  return (
                   <li key={index} className={styles.orderItem}>
  <span className={styles.productName}>{item.productName}</span>
  <span className={styles.productQuantity}>(x{item.quantity})</span>
  <span className={styles.priceSeparator}> - </span>
  <strong className={styles.productPrice}>
    {symbol} {formatNumberWithCommas(totalPrice)}
  </strong>
</li>
                  );
                })}
              </ul>

              <h5 className={styles.orderDetailHeading}>
                Total Cost:{" "}
                {(() => {
                  const currencySet = getCurrencySet(order.cart_items);
                  const showSymbol = currencySet.size === 1;
                  const symbol = showSymbol ? currencySymbols[[...currencySet][0]] || '' : '';
                  return `${symbol ? symbol + ' ' : ''}${formatNumberWithCommas(order.total_cost)}`;
                })()}
              </h5>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default Orders;







