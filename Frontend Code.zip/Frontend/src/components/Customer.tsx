import React, { useEffect, useState, useMemo } from 'react';
import { Navigate } from "react-router-dom";
import axios from 'axios';
import dayjs from 'dayjs';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useDebounce } from 'use-debounce';
import { motion } from "framer-motion";

type Customer = {
  id: number;
  name: string;
  email: string;
  phone: string;
  address: string;
  created_at: string; 
  productName?: string;
  vendorName?: string;
};

type Props = {
  isAdmin: boolean;
  isModerator: boolean;
};

type SearchField = 'name' | 'email' | 'vendor' | 'product' | 'all';

const Customer: React.FC<Props> = ({ isAdmin, isModerator }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearchTerm] = useDebounce(searchTerm, 300);
  const [searchField, setSearchField] = useState<SearchField>('all');
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [hiddenCustomerIds, setHiddenCustomerIds] = useState<number[]>(() => {
    const stored = localStorage.getItem("hiddenCustomers");
    return stored ? JSON.parse(stored) : [];
  });
  const [activeCategory, setActiveCategory] = useState("All");

  useEffect(() => {
    if (!isAdmin ) return;

    const fetchCustomers = async () => {
      try {
        const res = await axios.get<{ success: boolean; message: string; data: Customer[] }>(
          `${import.meta.env.VITE_PROHOMEZ_BACKEND_URL}/customersdata`
        );
        
        // Validate and normalize customer data
        const validatedData = res.data.data.map(customer => ({
          id: customer.id || 0,
          name: customer.name || '',
          email: customer.email || '',
          phone: customer.phone || '',
          address: customer.address || '',
          created_at: customer.created_at || new Date().toISOString(),
          productName: customer.productName || '',
          vendorName: customer.vendorName || ''
        }));

        console.log("Full customer data from API:", validatedData);
        setCustomers(validatedData);
      } catch (error) {
        console.error('Error fetching customer data:', error);
        toast.error("Failed to load customer data", {
          position: "top-right",
          autoClose: 3000,
        });
      }
    };

    fetchCustomers();
  }, [isAdmin]);

  console.log('Admin : ' , isAdmin);

  const getFilteredCustomers = () => {
    const now = dayjs();
    let visibleCustomers = customers.filter(c => !hiddenCustomerIds.includes(c.id));

   
<div className="flex gap-3 mt-4 mb-6">
  {["All", "Last Week", "Last Month"].map((cat) => (
    <motion.button
      key={cat}
      onClick={() => setActiveCategory(cat)}
      whileTap={{ scale: 0.95 }}
      whileHover={{ scale: 1.05 }}
      className={`px-5 py-2.5 rounded-full font-medium transition-colors duration-300 ${
        activeCategory === cat
          ? "bg-yellow-700 text-white shadow-md"
          : "bg-gray-200 text-gray-800 hover:bg-yellow-100"
      }`}
    >
      {cat}
    </motion.button>
  ))}
</div>



    const term = debouncedSearchTerm.toLowerCase().trim();

    if (term) {
      visibleCustomers = visibleCustomers.filter(customer => {
        const name = customer.name.toLowerCase();
        const email = customer.email.toLowerCase();
        const vendor = (customer.vendorName || "").toLowerCase()
        const product = (customer.productName || "").toLowerCase()

        switch (searchField) {
          case 'name':
            return name.includes(term);
          case 'email':
            return email.includes(term);
          case 'vendor':
            return vendor.includes(term);
          case 'product':
            return product.includes(term);
          case 'all':
          default:
            return (
              name.includes(term) ||
              email.includes(term) ||
              vendor.includes(term) ||
              product.includes(term)
            );
        }
      });

      // Sort by relevance
      visibleCustomers.sort((a, b) => {
        const getFieldValue = (customer: Customer, field: SearchField) => {
          switch (field) {
            case 'name': return customer.name.toLowerCase();
            case 'email': return customer.email.toLowerCase();
            case 'vendor': return (customer.vendorName || "").toLowerCase();
            case 'product': return (customer.productName || "").toLowerCase();

            default: return '';
          }
        };

        const aValue = getFieldValue(a, searchField === 'all' ? 'name' : searchField);
        const bValue = getFieldValue(b, searchField === 'all' ? 'name' : searchField);

        const calculateScore = (value: string) => {
          if (value === term) return 1000;
          if (value.toLowerCase() === term.toLowerCase()) return 950;
          if (value.toLowerCase().startsWith(term.toLowerCase())) {
            return value.startsWith(term) ? 800 : 700;
          }
          if (value.toLowerCase().includes(term.toLowerCase())) {
            return value.includes(term) ? 500 : 400;
          }
          return 0;
        };

        const aScore = searchField === 'all' 
          ? Math.max(
              calculateScore(a.name.toLowerCase()),
              calculateScore(a.email.toLowerCase()),
              calculateScore((a.vendorName || "").toLowerCase()),
              calculateScore((a.productName || "").toLowerCase()),

            )
          : calculateScore(aValue);

        const bScore = searchField === 'all'
          ? Math.max(
              calculateScore(b.name.toLowerCase()),
              calculateScore(b.email.toLowerCase()),
              calculateScore((b.vendorName || "").toLowerCase()),
              calculateScore((b.productName || "").toLowerCase()),


            )
          : calculateScore(bValue);

        return bScore - aScore;
      });
    }

    return visibleCustomers;
  };

  const filteredCustomers = useMemo(() => {
    const seen = new Set<number>();
    const result = getFilteredCustomers().filter(c => {
      if (seen.has(c.id)) return false;
      seen.add(c.id);
      return true;
    });
    
    console.log("Filtered Customers:", {
      term: debouncedSearchTerm,
      field: searchField,
      count: result.length,
      sample: result.slice(0, 3)
    });
    
    return result;
  }, [customers, hiddenCustomerIds, activeCategory, debouncedSearchTerm, searchField]);

  const handleDeleteCustomer = (id: number) => {
    if (!isAdmin) return;
    const updatedHidden = [...hiddenCustomerIds, id];
    setHiddenCustomerIds(updatedHidden);
    localStorage.setItem("hiddenCustomers", JSON.stringify(updatedHidden));

    toast.success("Customer Deleted.", {
      position: "top-right",
      autoClose: 3000,
      pauseOnHover: true,
      draggable: true,
      style: {
        borderRadius: '10px',
        background: '#333',
        color: '#fff',
      }
    });
  };

 if (!isAdmin && !isModerator) return <Navigate to="/login" />;
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Customer List</h2>
      
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
  <select
    value={searchField}
    onChange={(e) => setSearchField(e.target.value as SearchField)}
    className="p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-yellow-600 transition"
  >
    <option value="all">All Fields</option>
    <option value="name">Name</option>
    <option value="email">Email</option>
    <option value="vendor">Vendor</option>
    <option value="product">Product</option>
  </select>

  <input
    type="text"
    placeholder={`Search by ${searchField === 'all' ? 'any field' : searchField}`}
    value={searchTerm}
    onChange={(e) => setSearchTerm(e.target.value)}
    className="p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-yellow-600 transition col-span-2"
  />
</div>

<div
  style={{ marginTop: '16px', marginBottom: '32px' }}
  className="flex gap-3"
>
        {["All", "Last Week", "Last Month"].map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            style={{
              backgroundColor: activeCategory === cat ? 'rgb(131, 101, 49)' : '#f0f0f0',
              color: activeCategory === cat ? 'white' : '#333'
            }}
            className={`px-4 py-2 rounded font-medium transition hover:brightness-105`}
          >
            {cat}
          </button>
        ))}
      </div>

      {searchTerm && (
        <div className="mb-2 text-sm text-gray-600">
          Showing {filteredCustomers.length} results for "{searchTerm}" in {searchField === 'all' ? 'all fields' : searchField}
        </div>
      )}

      {filteredCustomers.length === 0 ? (
       <div className="flex flex-col items-center justify-center py-12 text-gray-500">
  <svg className="w-16 h-16 mb-4" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 9.75L14.25 14.25M14.25 9.75L9.75 14.25M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
  <p className="text-center text-lg font-medium">
    {searchTerm ? "No matching customers found." : "No customers available."}
  </p>
</div>

      ) : (
        <ul className="space-y-2">
          {filteredCustomers.map((customer) => (
            <li key={customer.id} className="border p-4 rounded shadow-sm">
              <div className="flex justify-between items-center">
                <div>
                  <p><strong>Name:</strong> {customer.name || 'N/A'}</p>
                  <p><strong>Email:</strong> {customer.email || 'N/A'}</p>
                  <p><strong>Phone:</strong> {customer.phone || 'N/A'}</p>
                  <p><strong>Address:</strong> {customer.address || 'N/A'}</p>
                  <p><strong>Vendor:</strong> {customer.vendorName || 'N/A'}</p>
                  <p><strong>Product:</strong> {customer.productName || 'N/A'}</p>
                  <p><strong>Joined:</strong> {dayjs(customer.created_at).format("MMM D, YYYY")}</p>
                </div>
                {isAdmin == true && (
                  <button
                    onClick={() => handleDeleteCustomer(customer.id)}
                    className="text-white px-4 py-2 rounded transition hover:brightness-110"
                    style={{ backgroundColor: 'rgb(131, 101, 49)' }}
                  >
                    Delete
                  </button>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
      <ToastContainer />
    </div>
  );
};

export default Customer;