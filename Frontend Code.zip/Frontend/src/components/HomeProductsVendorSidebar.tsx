import styles from '../style/HomeProductsVendorSidebar.module.css';
import vendorLogo from '../assets/images/WhatsApp Image 2025-03-13 at 23.10.23_ac2acca4.jpg';
import { VendorDetail } from './types';
import { useSelector } from 'react-redux';
import { RootState } from '../store/store';
import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import axios from 'axios';

const API_BASE = import.meta.env.VITE_PROHOMEZ_BACKEND_URL;

interface HomeProductsVendorSidebarProps {
    vendorDetail: VendorDetail;
}

function HomeProductsVendorSidebar({ vendorDetail }: HomeProductsVendorSidebarProps) {
    const [vendorData, setVendorData] = useState<VendorDetail | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [previewImage, setPreviewImage] = useState<string | null>(null);
    const store_id = vendorDetail.store_id;
    const { singleProduct } = useSelector((state: RootState) => state.products);

    useEffect(() => {
        let isMounted = true;
        
        const fetchVendorData = async () => {
            try {
                if (!store_id) {
                    setLoading(false);
                    return;
                }
                
                const response = await axios.get(`${API_BASE}/vendor-details/${store_id}`, {
                    headers: {
                        'Cache-Control': 'no-cache',
                        'Pragma': 'no-cache',
                        'Expires': '0'
                    }
                });
                
                if (isMounted) {
                    setVendorData(response.data);
                    
                    // Set the preview image
                    if (response.data.image) {
                        setPreviewImage(`${import.meta.env.VITE_PROHOMEZ_BACKEND_URL}/images/${response.data.image}`);
                    } else {
                        setPreviewImage(vendorLogo);
                    }
                }
            } catch (err) {
                if (isMounted) {
                    setError('Failed to fetch vendor details.');
                }
            } finally {
                if (isMounted) {
                    setLoading(false);
                }
            }
        };

        fetchVendorData();
        
        // Cleanup function to prevent state updates after unmount
        return () => {
            isMounted = false;
        };
    }, [store_id]); // This will refetch whenever store_id changes

    if (loading) return <div className={styles.loadingContainer}>Loading vendor details...</div>;
    if (error) return <div className={styles.errorContainer}>{error}</div>;
    if (!vendorData) return <div className={styles.errorContainer}>Vendor data not available.</div>;

    return (
        <div className={`${styles.homeProductsVendor}`}>
            <div className={`${styles.vendorDetailBox} d-flex`}>
                <div className={`${styles.imgBox}`}>
                    <Link 
                        to={`/pro/${
    (vendorDetail.store_name || 'no-store')
      .toLowerCase()
      .replace(/\s+/g, '-') 
      .replace(/[^\w-]/g, '') 
  }/${vendorDetail.store_id || ''}`}
                        className="flex justify-center"
                    >
                        <img
                            src={previewImage || vendorLogo}
                            alt="Vendor"
                            className={styles.VendorProfileImage}
                        />
                    </Link>
                </div>
                <div className={`${styles.vendorDetails}`}>
                    <Link 
                       to={`/pro/${
    (vendorDetail.store_name || 'no-store')
      .toLowerCase()
      .replace(/\s+/g, '-') 
      .replace(/[^\w-]/g, '') 
  }/${vendorDetail.store_id || ''}`}
                        className={`no-underline text-black ${styles.vendorProfileLink}`}
                    >
                        <h4 className={`${styles.vendorName}`}>
                            {vendorData.store_name || 'No Store Name'}
                        </h4>
                        <p className={`${styles.vendorDetail} mb-0`}>
                            {vendorData.email || 'No email provided'}
                        </p>
                        <p className={`${styles.vendorDetail} mb-0`}>
                            {vendorData.store_phone || 'No phone provided'}
                        </p>
                    </Link>
                </div>
            </div>
        </div>
    );
}

export default HomeProductsVendorSidebar;